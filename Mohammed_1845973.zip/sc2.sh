#!/bin/bash

# auther: Mohammed B. Fallatah
# last update: 03/01/2023

if [[ "$1" != *[*]* ]]
then
    echo "* is required"
	echo "$1/*"
else
	echo "Symbol is not required"
fi
